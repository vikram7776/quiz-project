from __future__ import unicode_literals

from django.contrib.auth.models import User
from django.db import models
import datetime                

# Create your models here.

class UserProfile(models.Model):
    user = models.OneToOneField(User)
    activation_key = models.CharField(max_length=40, blank=True)
    key_expires = models.DateTimeField(default=datetime.date.today())
      
    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural=u'User profiles'

class Quiz(models.Model):
    question = models.CharField(blank=True, max_length=400)
    choice1 = models.CharField(blank=True, max_length=400)
    choice2 = models.CharField(blank=True, max_length=400)
    choice3 = models.CharField(blank=True, max_length=400)
    choice4 = models.CharField(blank=True, max_length=400)
    def __unicode__(self):
        return self.question

class Correct(models.Model):
    answer = models.CharField(max_length=400,blank=True)
    def __unicode__(self):
	return self.answer

class Pdf(models.Model):
    title = models.CharField(max_length=100,blank=True)
    book = models.FileField(upload_to='pdfs',blank=True)
    def __unicode__(self):
	return self.title

class Com(models.Model):
    comment = models.TextField(max_length=200)
    def ___unicode__(self):
        return self.comment
