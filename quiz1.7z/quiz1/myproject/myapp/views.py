from django.shortcuts import render
from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib import auth
from django.core.context_processors import csrf
from forms import *
from models import *
from django.template import RequestContext
from django.core.mail import send_mail
import hashlib, datetime, random
from django.utils import timezone
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout

def search(request):
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        pdf = Pdf.objects.filter(book__icontains=q)
        return render(request, 'myapp/search_results.html', {'pdf': pdf, 'query': q})
    else:
        return HttpResponse('Please submit a search term.')


def solution(request):
    if 'an' in request.GET and request.GET['an']:
        obj = request.GET['an']
	l = Correct.objects.filter(answer__icontains=obj)
        if(l):	
	    return HttpResponse("Right Answer")
        else:
            return HttpResponse("Wrong Answer")

def comm(request):
    q = Com.objects.all()
    if request.method=="POST":
        form1=ComForm(request.POST)
	if form1.is_valid():
            post=form1.save(commit=False)
            post.save()
	    return render(request,'myapp/comment1.html',{'q':q})
    else:
        form1=ComForm()
        return render(request,'myapp/comment.html',{'form1':form1})

#def com1(request):
#	q = Com.objects.all()
#	return render(request,'myapp/comment1.html',{'q':q})


def index(request):
    return render(request,'myapp/index.html',{})

def signup(request):
    args = {}
    args.update(csrf(request))
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        args['form'] = form
        if form.is_valid(): 
            form.save()  # save user to database if form is valid

            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            salt = hashlib.sha1(str(random.random())).hexdigest()[:5]            
            activation_key = hashlib.sha1(salt+email).hexdigest()            
            key_expires = datetime.datetime.today() + datetime.timedelta(2)

            #Get user by username
            user=User.objects.get(username=username)

            # Create and save user profile                                                                                                                                  
            new_profile = UserProfile(user=user, activation_key=activation_key, 
                key_expires=key_expires)
            new_profile.save()

            # Send email with activation key
            email_subject = 'Account confirmation'
            email_body = "Hey %s, thanks for signing up. To activate your account, click this link within \
            48hours http://127.0.0.1:8000/confirm/%s" % (username, activation_key)

            send_mail(email_subject, email_body, 'myemail@example.com',
                [email], fail_silently=False)

            return HttpResponseRedirect('successful')
    else:
        args['form'] = RegistrationForm()

    return render_to_response('myapp/register.html', args, context_instance=RequestContext(request))



def register_confirm(request, activation_key):
    #check if user is already logged in and if he is redirect him to some other url, e.g. home
    if request.user.is_authenticated():
        HttpResponseRedirect('myapp/$')

    # check if there is UserProfile which matches the activation key (if not then display 404)
    user_profile = get_object_or_404(UserProfile, activation_key=activation_key)

    #check if the activation key has expired, if it hase then render confirm_expired.html
    if user_profile.key_expires < timezone.now():
        return render_to_response('myapp/confirm.html')
    #if the key hasn't expired save user and set him as active and render some template to confirm activation
    user = user_profile.user
    user.is_active = True
    user.save()
    return render_to_response('myapp/confirm.html')

def register_success(request):
    return HttpResponse('successful')

def login1(request):
    if request.method=="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        new_user = authenticate(username=username,password=password)
        if new_user is not None:
            if new_user.is_active:
                login(request,new_user)
                return render(request,'myapp/quiz.html',{})
            else:
                return HttpResponse("Disabled account")
            
        else:
             return HttpResponse("Invalid Login")
    else:
        return render(request,'myapp/login.html',{})



def about(request):
    return render(request,'myapp/about.html',{})

def contact(request):
    return render(request,'myapp/contact.html',{})

def category(request):
    return render(request,'myapp/category.html',{})

def join(request):
    return render(request,'myapp/join.html',{})

def read(request):
    return render(request,'myapp/read.html',{})

def pdf1(request):
    return render(request,'myapp/pdf1.html',{})

def pdf2(request):
    return render(request,'myapp/pdf2.html',{})

def pdf3(request):
    return render(request,'myapp/pdf3.html',{})

def pdf4(request):
    return render(request,'myapp/pdf4.html',{})

def test1(request):
    q = Quiz.objects.all()[:10]
    return render(request,'myapp/test1.html',{'q':q})

def test2(request):
    q = Quiz.objects.all()[10:20]
    return render(request,'myapp/test1.html',{'q':q})

def test3(request):
    q = Quiz.objects.all()[20:30]
    return render(request,'myapp/test1.html',{'q':q})

def test4(request):
    q = Quiz.objects.all()[30:40]
    return render(request,'myapp/test1.html',{'q':q})








