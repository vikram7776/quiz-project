func1(){


alert("hi")

}
