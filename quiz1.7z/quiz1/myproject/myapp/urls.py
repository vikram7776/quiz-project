from django.conf.urls import url

from . import views

urlpatterns=[

url(r'^$',views.index,name='index'),
url(r'^myapp/about/$', views.about, name='about'),
url(r'^myapp/contact/$', views.contact, name='contact'),
url(r'^myapp/signup/',views.signup,name='signup'),
url(r'^register_success/$', views.register_success,name='register_success'),
url(r'^confirm/(?P<activation_key>\w+)/$', views.register_confirm,name='register_confirm'),
url(r'^login1/$', views.login1,name='login1'),
url(r'^test1/$',views.test1,name='test1'),
url(r'^test2/$',views.test2,name='test2'),
url(r'^test3/$',views.test3,name='test3'),
url(r'^test4/$',views.test4,name='test4'),
url(r'^comm/$',views.comm,name='comm'),
#url(r'^com1/$',views.com1,name='com1'),
url(r'^myapp/category/$',views.category,name='category'),
url(r'^myapp/join/$',views.join,name='join'),
url(r'^myapp/read/$',views.read,name='read'),
url(r'^myapp/pdf1/$',views.pdf1,name='pdf1'),
url(r'^myapp/pdf2/$',views.pdf2,name='pdf2'),
url(r'^myapp/pdf3/$',views.pdf3,name='pdf3'),
url(r'^myapp/pdf4/$',views.pdf4,name='pdf4'),
url(r'^search/?$',views.search, name='search'),
url(r'^solution/?$', views.solution, name='solution'),
]
